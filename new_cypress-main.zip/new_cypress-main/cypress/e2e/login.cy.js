describe('Проверка авторизации', function () {

    it('Верный пароль и верный логин', function () {
         cy.visit('https://login.qa.studio/'); //зашли на сайт
         cy.get('#mail').type('german@dolnikov.ru')// ввели логин
         cy.get('#pass').type('iLoveqastudio1') // ввели пароль
         cy.get('#loginButton').click(); // нажали войти
         cy.get('#messageHeader').contains('Авторизация прошла успешно'); // проверили нужный текст
         cy.get('#exitMessageButton > .exitIcon').should('be.visible');// есть крестик

        })
    it('Проверка логики восстановления', function () {
        cy.visit('https://login.qa.studio/'); //зашли на сайт
        cy.get('#forgotEmailButton').click(); // нажали войти
        cy.get('#forgotForm > .header').contains('Восстановите пароль'); // проверили нужный текст
        cy.get('#mailForgot').type('Simran-95@mail.ru')// ввели логин
        cy.get('#restoreEmailButton').click() //нажали отправить код
        cy.get('#messageHeader').contains('Успешно отправили пароль на e-mail') //Проверили нужный текст
    })


    it('верный логин и не верный пароль', function () {
        cy.visit('https://login.qa.studio/'); //зашли на сайт
        cy.get('#mail').type('german@dolnikov.ru')// ввели логин
        cy.get('#pass').type('iLoveqastudio') // ввели не правильный пароль
        cy.get('#loginButton').click(); // нажали войти
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); // проверили нужный текст

       })

       it('не верный логин и  верный пароль', function () {
        cy.visit('https://login.qa.studio/'); //зашли на сайт
        cy.get('#mail').type('german@olnikov.ru')// ввели не правильный логин
        cy.get('#pass').type('iLoveqastudio1') // ввели правильный пароль
        cy.get('#loginButton').click(); // нажали войти
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); // проверили нужный текст

       })
       
       it('Ошибка валидации', function () {
        cy.visit('https://login.qa.studio/'); //зашли на сайт
        cy.get('#mail').type('germandolnikov.ru')// ввели правильный логин
        cy.get('#pass').type('iLoveqastudio1') // ввели правильный пароль
        cy.get('#loginButton').click(); // нажали войти
        cy.get('#messageHeader').contains('Нужно исправить проблему валидации'); // проверили нужный текст

       })
       it('приведение к строчным буквам в логине', function () {
        cy.visit('https://login.qa.studio/'); //зашли на сайт
        cy.get('#mail').type('GerMan@Dolnikov.ru')// ввели логин
        cy.get('#pass').type('iLoveqastudio1') // ввели правильный пароль
        cy.get('#loginButton').click(); // нажали войти
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); // проверили нужный текст
        cy.get('#exitMessageButton > .exitIcon').should('be.visible');   // есть крестик

       })

   })

 